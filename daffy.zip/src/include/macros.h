#ifndef DAF_MACROS_H
#define DAF_MACROS_H
#define MAX(a, b) \
    a > b ? a : b
#define MIN(a, b) \
    a < b ? a : b
#endif
