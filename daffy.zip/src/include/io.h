#ifndef DAF_IO_H
#define DAF_IO_H

char* daf_read_file(const char* filename);
void daf_write_file(const char* filename, char* buf);

#endif
