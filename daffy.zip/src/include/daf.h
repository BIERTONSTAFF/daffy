#ifndef DAF_H
#define DAF_H

void daf_compile(char* src);

void daf_compile_file(const char* filename);

#endif