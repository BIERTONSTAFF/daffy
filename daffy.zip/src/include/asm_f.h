#ifndef DAF_ASM_F_H
#define DAF_ASM_F_H
#include "ast.h"

char* asm_f_root(ast_t* ast);
char* asm_f(ast_t* ast);

#endif
