#ifndef DAF_TYPES_H
#define DAF_TYPES_H

int typename_to_int(const char* name);

#endif
